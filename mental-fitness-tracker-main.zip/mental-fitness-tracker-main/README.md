# mental-fitness-tracker by saswat
the mental fitness tracker is built using google colab providing a user_friendly devlopement environment.
key components including preprocessing,feature engineeering model training and result analysis.
various python libraries and frameworks are used such as pandas,scikit-learn and matplotlib
